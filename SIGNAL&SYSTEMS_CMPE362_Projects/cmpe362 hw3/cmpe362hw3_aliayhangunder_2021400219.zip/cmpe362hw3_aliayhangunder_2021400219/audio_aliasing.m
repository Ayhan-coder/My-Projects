% CMPE362 HW3 - Audio Aliasing
% Author: Ali Ayhan Günder - 2021400219
% Date: 2026-03-07
% Part 1: Audio Aliasing
% Generate a 2 second 1800 Hz cosine wave at sample rates 2000 and 4000.
f = 1800;
dur = 2;

% Set false if you do not want to play audio
playAudio = true;

% Sample rate 2000
fs1 = 2000;
t1 = 0:1/fs1:dur-1/fs1;
y1 = cos(2*pi*f*t1);

% Sample rate 4000
fs2 = 4000;
t2 = 0:1/fs2:dur-1/fs2;
y2 = cos(2*pi*f*t2);

% Listen to the audio
if playAudio
    disp('Playing 1800 Hz at 2000 Hz sample rate...');
    sound(y1, fs1);
    pause(dur + 1);

    disp('Playing 1800 Hz at 4000 Hz sample rate...');
    sound(y2, fs2);
    pause(dur + 1);
end

% Generate 200 Hz at 2000 sample rate
f_low = 200;
y_low = cos(2*pi*f_low*t1);
if playAudio
    disp('Playing 200 Hz at 2000 Hz sample rate...');
    sound(y_low, fs1);
    pause(dur + 1);
end

% Plot the spectrograms
figure('Name', 'Audio Aliasing Spectrograms', 'Position', [100, 100, 800, 600]);

subplot(3, 1, 1);
my_spectrogram(y_low(:), fs1);
title('200 Hz at 2000 Sample Rate');

subplot(3, 1, 2);
my_spectrogram(y1(:), fs1);
title('1800 Hz at 2000 Sample Rate');

subplot(3, 1, 3);
my_spectrogram(y2(:), fs2);
title('1800 Hz at 4000 Sample Rate');

disp('Audio script complete. Spectrograms plotted.');

function my_spectrogram(x, fs)
    nfft = 256;
    noverlap = 128;
    nwind = 256;
    window = 0.54 - 0.46*cos(2*pi*(0:nwind-1)'/(nwind-1)); % Hamming
    
    nx = length(x);
    ncol = fix((nx-noverlap)/(nwind-noverlap));
    
    colindex = 1 + (0:(ncol-1))*(nwind-noverlap);
    rowindex = (1:nwind)';
    
    if length(x)<(nwind+colindex(ncol)-1)
        x(nwind+colindex(ncol)-1) = 0;   % zero-pad x
    end
    
    y = zeros(nwind,ncol);
    y(:) = x(rowindex(:,ones(1,ncol))+colindex(ones(nwind,1),:)-1);
    
    y = window(:,ones(1,ncol)) .* y;
    
    Y = fft(y, nfft);
    Y = Y(1:nfft/2+1, :);
    
    f = (0:nfft/2)*fs/nfft;
    t = (colindex-1)/fs;
    
    imagesc(t, f, 10*log10(abs(Y) + 1e-6));
    axis xy;
    colormap jet;
    ylabel('Frequency (Hz)');
    xlabel('Time (s)');
end
