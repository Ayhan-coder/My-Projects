% CMPE362 HW3 - Image Aliasing
% Author: Ali Ayhan Günder - 2021400219
% Date: 2026-03-07
% Part 2: Image
% Generate the image cos((x+2y)^2) in grayscale in x=(-10,10) and y=(-10,10)

% Define a function to generate the image at a specific resolution
generate_image = @(res) cos((meshgrid(linspace(-10, 10, res)) + 2*meshgrid(linspace(-10, 10, res))').^2);

% The formula is cos((x+2y)^2)
% Let's be explicit with meshgrid
res_levels = [2000, 500, 150, 50];
images = cell(1, length(res_levels));

for i = 1:length(res_levels)
    res = res_levels(i);
    [x, y] = meshgrid(linspace(-10, 10, res), linspace(-10, 10, res));
    images{i} = cos((x + 2*y).^2);
end

figure('Name', 'Image Aliasing', 'Position', [100, 100, 800, 800]);

% Plot 2000x2000
subplot(2, 2, 1);
imshow(images{1}, [-1 1], 'InitialMagnification', 'fit');
title('2000x2000 (Original)');

% Plot 500x500
subplot(2, 2, 2);
imshow(images{2}, [-1 1], 'InitialMagnification', 'fit');
title('500x500 (Undersampled)');

% Plot 150x150
subplot(2, 2, 3);
imshow(images{3}, [-1 1], 'InitialMagnification', 'fit');
title('150x150 (Undersampled)');

% Plot 50x50
subplot(2, 2, 4);
imshow(images{4}, [-1 1], 'InitialMagnification', 'fit');
title('50x50 (Undersampled)');

disp('Image script complete. Images plotted.');
