% CMPE362 - Homework 2
% Fourier Synthesis and Gibbs Phenomenon
% Name: Ali Ayhan Günder
% Student ID: 2021400219
% Date: 2026-03-07

clear; clc; close all;

%% General Settings
fs = 10000;             % High sample rate to observe Gibbs phenomenon
T = 2;                  % Period of the signals (seconds)
t = -1.5*T : 1/fs : 1.5*T; % Time vector (showing multiple periods)
f0 = 1/T;               % Fundamental frequency
w0 = 2*pi*f0;           % Fundamental angular frequency

harmonics = [5, 20, 100]; % Number of harmonics to use
colors = ['r', 'g', 'b']; % Colors for plotting

%% 1. Square Wave
% Analytical definition (Target)
% Square wave with amplitude 1, period T
% Note: Using sign(sin(...)) to avoid dependency on Signal Processing Toolbox
target_square = sign(sin(w0 * t));

figure('Name', 'Square Wave Fourier Synthesis', 'Position', [100, 100, 1200, 800]);

% Plot 1: Full view
subplot(2, 1, 1);
plot(t, target_square, 'k', 'LineWidth', 2, 'Color', [0.8, 0.8, 0.8]); hold on;
legend_str = {'Target'};

for i = 1:length(harmonics)
    N = harmonics(i);
    approx = zeros(size(t));
    % Fourier Series for Square Wave (odd harmonics only)
    % f(t) = 4/pi * sum_{n=1,3,5...} (1/n * sin(n*w0*t))
    for n = 1:2:(2*N - 1) % Summing first N non-zero terms (which are odd numbers)
        approx = approx + (4/pi) * (1/n) * sin(n * w0 * t);
    end
    
    plot(t, approx, 'LineWidth', 1.5, 'Color', colors(i));
    legend_str{end+1} = sprintf('n = %d', N);
end

title('Square Wave Approximation');
xlabel('Time (s)'); ylabel('Amplitude');
legend(legend_str, 'Location', 'northeast');
grid on;
xlim([-0.5*T, 1.5*T]);

% Plot 2: Zoomed view (near discontinuity at t=0)
subplot(2, 1, 2);
plot(t, target_square, 'k', 'LineWidth', 2, 'Color', [0.8, 0.8, 0.8]); hold on;

for i = 1:length(harmonics)
    N = harmonics(i);
    approx = zeros(size(t));
    for n = 1:2:(2*N - 1)
        approx = approx + (4/pi) * (1/n) * sin(n * w0 * t);
    end
    plot(t, approx, 'LineWidth', 1.5, 'Color', colors(i));
end

title('Square Wave - Zoomed at Discontinuity');
xlabel('Time (s)'); ylabel('Amplitude');
% Zoom near t = 0 (rising edge)
xlim([-0.05*T, 0.05*T]); 
ylim([-1.2, 1.2]);
grid on;

saveas(gcf, 'square_wave_analysis.png');

%% 2. Triangular Wave
% Analytical definition (Target)
% Note: Using (2/pi)*asin(sin(...)) to generate triangle wave without toolbox
% We shift phase by pi/2 to match the cosine-based Fourier series standard or sawtooth behavior
% target_triangle was sawtooth(w0 * t + pi/2, 0.5);
% sawtooth(t, 0.5) generates values between -1 and 1.
% asin(sin(t)) generates a triangle wave between -pi/2 and pi/2.
% (2/pi)*asin(sin(t)) is between -1 and 1.
target_triangle = (2/pi) * asin(sin(w0 * t));  

figure('Name', 'Triangular Wave Fourier Synthesis', 'Position', [150, 150, 1200, 800]);

% Plot 1: Full view
subplot(2, 1, 1);
plot(t, target_triangle, 'k', 'LineWidth', 2, 'Color', [0.8, 0.8, 0.8]); hold on;
legend_str = {'Target'};

for i = 1:length(harmonics)
    N = harmonics(i);
    approx = zeros(size(t));
    % Fourier Series for Triangle Wave
    % f(t) = 8/pi^2 * sum_{n=1,3,5...} ((-1)^((n-1)/2) / n^2 * sin(n*w0*t))
    k = 0;
    for n = 1:2:(2*N - 1)
        term = ((-1)^k) / (n^2) * sin(n * w0 * t);
        approx = approx + term;
        k = k + 1;
    end
    approx = approx * (8/pi^2);
    
    plot(t, approx, 'LineWidth', 1.5, 'Color', colors(i));
    legend_str{end+1} = sprintf('n = %d', N);
end

title('Triangular Wave Approximation');
xlabel('Time (s)'); ylabel('Amplitude');
legend(legend_str, 'Location', 'northeast');
grid on;
xlim([-0.5*T, 1.5*T]);

% Plot 2: Zoomed view
subplot(2, 1, 2);
plot(t, target_triangle, 'k', 'LineWidth', 2, 'Color', [0.8, 0.8, 0.8]); hold on;

for i = 1:length(harmonics)
    N = harmonics(i);
    approx = zeros(size(t));
    k = 0;
    for n = 1:2:(2*N - 1)
        term = ((-1)^k) / (n^2) * sin(n * w0 * t);
        approx = approx + term;
        k = k + 1;
    end
    approx = approx * (8/pi^2);
    plot(t, approx, 'LineWidth', 1.5, 'Color', colors(i));
end

title('Triangular Wave - Zoomed at Peak');
xlabel('Time (s)'); ylabel('Amplitude');
% Zoom near t = T/4 (peak)
xlim([T/4 - 0.05*T, T/4 + 0.05*T]);
ylim([0.8, 1.05]);
grid on;

saveas(gcf, 'triangle_wave_analysis.png');

%% 3. Full-Wave Rectified Sine Wave
% Analytical definition (Target)
target_rectified = abs(sin(w0/2 * t)); % Frequency is doubled essentially for full wave

figure('Name', 'Full-Wave Rectified Sine Fourier Synthesis', 'Position', [200, 200, 1200, 800]);

% Plot 1: Full view
subplot(2, 1, 1);
plot(t, target_rectified, 'k', 'LineWidth', 2, 'Color', [0.8, 0.8, 0.8]); hold on;
legend_str = {'Target'};

for i = 1:length(harmonics)
    N = harmonics(i);
    approx = zeros(size(t));
    % Fourier Series for Full-Wave Rectified Sine
    % f(t) = 2/pi - 4/pi * sum_{n=1}^{\infty} (1/(4n^2-1) * cos(2n*w0_sine*t))
    % Note: The fundamental frequency of the rectified wave is 2*f_sine.
    % Let's treat the period of the rectified wave as T_rect = T_sine / 2.
    
    % DC Component
    approx = approx + 2/pi;
    
    % AC Components
    % Summing over k = 1 to N
    for n = 1:N
        term = (1 / (4*n^2 - 1)) * cos(n * w0 * t); % w0 here is the fundamental of the rectified wave
        approx = approx - (4/pi) * term;
    end
    
    plot(t, approx, 'LineWidth', 1.5, 'Color', colors(i));
    legend_str{end+1} = sprintf('n = %d', N);
end

title('Full-Wave Rectified Sine Approximation');
xlabel('Time (s)'); ylabel('Amplitude');
legend(legend_str, 'Location', 'northeast');
grid on;
xlim([-0.5*T, 1.5*T]);

% Plot 2: Zoomed view (near sharp transition at t = 0)
subplot(2, 1, 2);
plot(t, target_rectified, 'k', 'LineWidth', 2, 'Color', [0.8, 0.8, 0.8]); hold on;

for i = 1:length(harmonics)
    N = harmonics(i);
    approx = zeros(size(t));
    approx = approx + 2/pi;
    for n = 1:N
        term = (1 / (4*n^2 - 1)) * cos(n * w0 * t);
        approx = approx - (4/pi) * term;
    end
    plot(t, approx, 'LineWidth', 1.5, 'Color', colors(i));
end

title('Full-Wave Rectified Sine - Zoomed at Cusp');
xlabel('Time (s)'); ylabel('Amplitude');
% Zoom near t = 0 (cusp)
xlim([-0.05*T, 0.05*T]);
ylim([-0.1, 0.3]);
grid on;

saveas(gcf, 'rectified_sine_analysis.png');

%% Gibbs Phenomenon Analysis (Console Output)
fprintf('--------------------------------------------------\n');
fprintf('Analysis of Gibbs Phenomenon:\n');
fprintf('--------------------------------------------------\n');
fprintf('1. Square Wave:\n');
fprintf('   - Discontinuity: Yes (at t=0, t=T/2, etc.)\n');
fprintf('   - Gibbs Phenomenon: Clearly visible overshoot/undershoot.\n');
fprintf('   - Overshoot remains constant amplitude approx 9%% as N increases, but becomes narrower.\n\n');

fprintf('2. Triangular Wave:\n');
fprintf('   - Discontinuity: No. The function is continuous, but derivative is discontinuous.\n');
fprintf('   - Gibbs Phenomenon: Not observed. Convergence is fast (1/n^2).\n\n');

fprintf('3. Full-Wave Rectified Sine:\n');
fprintf('   - Discontinuity: No. Function continuous, derivative discontinuous at cusps.\n');
fprintf('   - Gibbs Phenomenon: Not observed. Convergence is relatively fast.\n\n');
