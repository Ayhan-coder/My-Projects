# CMPE476 — C10K Project

## Group Members

| Name | Student ID | Contribution |
|------|-----------|--------------|
| [Your Name] | [Your Student ID] | Implemented both servers (threadserv, epollserv), protocol and buffer modules, and wrote the benchmark report. |

## Building

```bash
make          # builds threadserv and epollserv
make test     # builds and runs the CUnit test suite
make clean    # removes all generated files
```

## Running

```bash
./threadserv 9090   # thread-per-connection server on port 9090
./epollserv 9091    # epoll event-loop server on port 9091
```
