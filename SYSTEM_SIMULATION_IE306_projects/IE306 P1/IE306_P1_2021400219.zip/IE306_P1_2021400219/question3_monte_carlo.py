"""
IE 306 Assignment 1 - Question 3
Monte Carlo Integration of y = x^4 - 3x^3 + 3*sin(2x^2) + 12 over [0, 3]

Method: Hit-or-Miss (Geometric) Monte Carlo
  - Generate random (x, y) pairs in the bounding rectangle [0,3] x [y_min, y_max]
  - Estimate integral = area_of_rectangle * (hits / total_samples)

We also compare with the analytical/numerical value for precision assessment.
"""
# @author: Ali Ayhan Günder - 2021400219
# @date: 2026-04-03



import random
import math

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False

# -- Function definition -----------------------------------------------
def f(x):
    return x**4 - 3*x**3 + 3*math.sin(2*x**2) + 12

# -- Determine bounding box over [0, 3] --------------------------------
# f(x) > 0 for all x in [0,3], so Y_MIN = 0 is the natural lower bound.
xs = [i * 0.001 for i in range(3001)]
ys = [f(x) for x in xs]
Y_MIN = 0.0
Y_MAX = max(ys) * 1.05   # 5% headroom above max

X_MIN, X_MAX = 0.0, 3.0
BOX_WIDTH  = X_MAX - X_MIN
BOX_HEIGHT = Y_MAX - Y_MIN
BOX_AREA   = BOX_WIDTH * BOX_HEIGHT

print("=" * 60)
print("Q3: Monte Carlo Integration")
print(f"    f(x) = x^4 - 3x^3 + 3*sin(2x^2) + 12  over [0, 3]")
print(f"    Bounding box: x in [0, 3], y in [{Y_MIN:.4f}, {Y_MAX:.4f}]")
print(f"    Box area: {BOX_AREA:.4f}")
print("=" * 60)

# -- Numerical reference value (composite Simpson's rule) --------------
def simpsons_quad(func, a, b, n=10000):
    """Composite Simpson's rule for numerical integration."""
    if n % 2 == 1:
        n += 1
    h = (b - a) / n
    s = func(a) + func(b)
    for i in range(1, n, 2):
        s += 4 * func(a + i * h)
    for i in range(2, n, 2):
        s += 2 * func(a + i * h)
    return s * h / 3

ref_value = simpsons_quad(f, 0, 3)
print(f"\nReference (numerical) integral: {ref_value:.6f}")
print()

# -- Monte Carlo simulation for N = 100, 500, 1000 --------------------
random.seed(2024)

sample_sizes = [100, 500, 1000]

print(f"{'N':>6} | {'Estimate':>12} | {'Error':>10} | {'Rel Error (%)':>14}")
print("-" * 50)

for N in sample_sizes:
    hits = 0
    for _ in range(N):
        x_rand = random.uniform(X_MIN, X_MAX)
        y_rand = random.uniform(Y_MIN, Y_MAX)
        f_val  = f(x_rand)

        # A point (x_rand, y_rand) is a 'hit' if it falls under the curve.
        # Since f(x) > 0 everywhere, hit means: 0 <= y_rand <= f(x_rand)
        if 0 <= y_rand <= f_val:
            hits += 1

    estimate  = BOX_AREA * (hits / N)
    error     = abs(estimate - ref_value)
    rel_error = 100.0 * error / abs(ref_value)

    print(f"{N:>6} | {estimate:>12.6f} | {error:>10.6f} | {rel_error:>13.2f}%")

print("-" * 50)
print()

# -- Detailed output for each sample size ------------------------------
print("Detailed Results:")
print()
random.seed(2024)  # reset for reproducible detailed run

for N in sample_sizes:
    hits = 0
    for _ in range(N):
        x_rand = random.uniform(X_MIN, X_MAX)
        y_rand = random.uniform(Y_MIN, Y_MAX)
        f_val  = f(x_rand)
        if 0 <= y_rand <= f_val:
            hits += 1

    estimate  = BOX_AREA * (hits / N)
    error     = abs(estimate - ref_value)
    rel_error = 100.0 * error / abs(ref_value)

    print(f"  N = {N}")
    print(f"    Hits:               {hits} / {N}  ({100*hits/N:.1f}%)")
    print(f"    Box Area:           {BOX_AREA:.4f}")
    print(f"    MC Estimate:        {estimate:.4f}")
    print(f"    Reference value:    {ref_value:.4f}")
    print(f"    Absolute Error:     {error:.4f}")
    print(f"    Relative Error:     {rel_error:.2f}%")
    print()

# -- Generate Excel file if openpyxl is available ----------------------
if OPENPYXL_AVAILABLE:
    wb = Workbook()
    ws = wb.active
    ws.title = "Q3 Monte Carlo Integration"

    # Title
    ws['A1'] = "Question 3: Monte Carlo Integration"
    ws['A1'].font = Font(bold=True, size=14)
    ws.merge_cells('A1:G1')

    # Problem Statement
    ws['A3'] = "Problem:"
    ws['A3'].font = Font(bold=True)
    ws['A4'] = "Estimate I = ∫₀³ (x⁴ - 3x³ + 3sin(2x²) + 12) dx"
    ws['A4'].font = Font(italic=True)

    # Method
    ws['A6'] = "Bounding Box:"
    ws['A6'].font = Font(bold=True)
    ws['A7'] = "x interval: [0, 3]"
    ws['B7'] = 3.0
    ws['A8'] = "y interval: [0, Y_max]"
    ws['B8'] = f"{Y_MAX:.4f}"
    ws['A9'] = "Box Area"
    ws['B9'] = f"{BOX_AREA:.4f}"
    ws['B9'].font = Font(bold=True)
    ws['B9'].fill = PatternFill(start_color="FFFFCC", end_color="FFFFCC", fill_type="solid")

    # Reference Value
    ws['A11'] = "Reference Value (Simpson's Rule):"
    ws['A11'].font = Font(bold=True)
    ws['A12'] = "I_reference"
    ws['B12'] = ref_value
    ws['B12'].number_format = '0.0000'
    ws['B12'].font = Font(bold=True)
    ws['B12'].fill = PatternFill(start_color="FFFFCC", end_color="FFFFCC", fill_type="solid")

    # Results Table
    ws['A14'] = "Monte Carlo Results:"
    ws['A14'].font = Font(bold=True, size=12)

    headers = ["N", "Hits", "Hit Ratio (%)", "Estimate", "Reference", "Abs Error", "Rel Error (%)"]
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=15, column=col_idx)
        cell.value = header
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        cell.alignment = Alignment(horizontal="center", vertical="center")

    # Collect results for Excel
    random.seed(2024)  # Reset seed for data collection
    for row_idx, N in enumerate(sample_sizes, 16):
        hits = 0
        for _ in range(N):
            x_rand = random.uniform(X_MIN, X_MAX)
            y_rand = random.uniform(Y_MIN, Y_MAX)
            f_val = f(x_rand)
            if 0 <= y_rand <= f_val:
                hits += 1

        estimate = BOX_AREA * (hits / N)
        error = abs(estimate - ref_value)
        rel_error = 100.0 * error / abs(ref_value)
        hit_ratio = 100.0 * hits / N

        ws.cell(row=row_idx, column=1, value=N).alignment = Alignment(horizontal="center")
        ws.cell(row=row_idx, column=2, value=hits).alignment = Alignment(horizontal="center")
        
        cell = ws.cell(row=row_idx, column=3, value=hit_ratio)
        cell.number_format = '0.0'
        cell.alignment = Alignment(horizontal="center")
        
        cell = ws.cell(row=row_idx, column=4, value=estimate)
        cell.number_format = '0.0000'
        cell.alignment = Alignment(horizontal="center")
        
        cell = ws.cell(row=row_idx, column=5, value=ref_value)
        cell.number_format = '0.0000'
        cell.alignment = Alignment(horizontal="center")
        
        cell = ws.cell(row=row_idx, column=6, value=error)
        cell.number_format = '0.0000'
        cell.alignment = Alignment(horizontal="center")
        
        cell = ws.cell(row=row_idx, column=7, value=rel_error)
        cell.number_format = '0.00'
        cell.alignment = Alignment(horizontal="center")

    # Notes
    ws['A20'] = "Notes:"
    ws['A20'].font = Font(bold=True)
    ws['A21'] = "Random seed: 2024 (reproducible)"
    ws['A22'] = "Method: Hit-or-Miss geometric Monte Carlo"
    ws['A23'] = "Estimate = (hits / N) × Box Area"

    # Column widths
    ws.column_dimensions['A'].width = 20
    ws.column_dimensions['B'].width = 15
    ws.column_dimensions['C'].width = 15
    ws.column_dimensions['D'].width = 15
    ws.column_dimensions['E'].width = 15
    ws.column_dimensions['F'].width = 15
    ws.column_dimensions['G'].width = 18

    # Save
    wb.save('Question3_Monte_Carlo_Results.xlsx')
    print("Excel file generated: Question3_Monte_Carlo_Results.xlsx")
else:
    print("\nNote: openpyxl not installed. Install with: pip install openpyxl")
    print("to generate Excel file automatically.")
